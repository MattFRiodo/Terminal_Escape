#include <iostream>
#include <string>
#include <fstream>
#include <vector>
using namespace std;

// read progress
vector<int> loadProgress() {
	vector<int> completed;
ifstream file(".Mission_Progress.txt");
	int level;
	while (file >> level) {
		completed.push_back(level);
	}
	return completed;
}

// write progress
void saveProgress(int level) {
ofstream file(".Mission_Progress.txt", ios::app);
	file << level << endl;
}

int main(int argc, char* argv[]) {
	// usage info
	if (argc < 3) {
		cout << "Usage: ./validator.exe <level> <flag>" << endl;
		return 1;
	}

	// flag storage
	int level = stoi(argv[1]);
	string flag = argv[2];
	cout << "Level: " << level << endl;
	cout << "Flag: " << flag << endl;

	// correct flags
	string correct_flags[5] = {
		"FLAG{Ar3a51_H1dd3n_F1l3}",
		"FLAG{D3c0d3d_Tr4nsm1ss10n}",
		"FLAG{P3rm1ss10n_Gr4nt3d}",
		"FLAG{S3cr3t_R3c0v3r3d}",
		"FLAG{Y0u_Esc4p3d_Th3_T3rm1n4l}"
	};

	// load completed levels
	vector<int> completed = loadProgress();

	for (int i = 0; i < completed.size(); i++) {
		if (completed[i] == level) {
			cout << "Flag has already been found, Agent!" << endl;
			return 0;
		}
	}

	// verification
	if (flag == correct_flags[level - 1]) {
		saveProgress(level);
		cout << "The correct flag has been found, continue with the mission.\n" << endl;
		system("./Terminal_Escape.exe && bash");
	} else {
		cout << "Wrong flag. Keep searching agent." << endl;
		return 1;
	}
}
