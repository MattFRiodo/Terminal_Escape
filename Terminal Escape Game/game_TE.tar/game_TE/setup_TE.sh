#!/bin/bash
echo "Setting up Terminal Escape..."

#level directory setup
mkdir -p .Level_1
mkdir -p .Level_2
mkdir -p .Level_3
mkdir -p .Level_4
mkdir -p .Level_5

# Level 1
echo "FLAG{Ar3a51_H1dd3n_F1l3}" > .Level_1/.hidden_secret
echo "Agent, you have successfully infiltrated the Area 51 terminal. Intelligence suggests the first secret file is somewhere in this directory. But their systems hide files from plain view. Look closer." > .Level_1/mission.txt
echo "To use the validator, first do cd .. then ./validator.exe" > .Level_1/validator_instruction.txt

# Level 2
echo "FLAG{D3c0d3d_Tr4nsm1ss10n}" | base64 > .Level_2/transmission.txt
echo "Good work Agent. We intercepted a transmission from Area 51 but it appears to be encoded. Their systems scramble all outgoing messages. Decode it to find the next secret." > .Level_2/mission.txt

# Level 3
echo "FLAG{P3rm1ss10n_Gr4nt3d}" > .Level_3/classified.txt
chmod 000 .Level_3/classified.txt
echo "The next file has been locked down by Area 51 security protocols. Their access control system is preventing you from reading it. You will need to override the permissions to get through." > .Level_3/mission.txt

# Level 4
python3 -c "
import random
import string

def random_chunk():
    chars = string.ascii_letters + string.digits + string.punctuation + ' '
    length = random.randint(20, 60)
    return ''.join(random.choice(chars) for _ in range(length))

chunks = [random_chunk() for _ in range(500)]
flag_pos = random.randint(100, 400)
chunks.insert(flag_pos, 'FLAG{S3cr3t_R3c0v3r3d}')
print(''.join(chunks))
" > .Level_4/intel_dump.txt
echo "Area 51 dumped their entire intel database to slow you down. The secret is in there somewhere but buried under hundreds of fake entries. Filter through the noise, Agent." > .Level_4/mission.txt

# Level 5
cat > .Level_5/secret.cpp << 'EOF'
#include <iostream>
int main() {
    const char* clearance = "FLAG{Y0u_Esc4p3d_Th3_T3rm1n4l}";
    std::cout << "ACCESS DENIED. SECURITY CLEARANCE REQUIRED." << std::endl;
    return 0;
}
EOF
g++ .Level_5/secret.cpp -o .Level_5/area51_security
rm .Level_5/secret.cpp
echo "This is it Agent. The final secret is locked inside Area 51's own compiled security program. They thought no one could crack a binary. Prove them wrong and escape the terminal." > .Level_5/mission.txt

# Compile programs
echo "Compiling programs..."
g++ .validator.cpp -o validator.exe
g++ .launcher.cpp -o Terminal_Escape.exe

# Reset progress
rm -f .Mission_Progress.txt

echo "======================="
echo "Terminal Escape is ready!"
echo "Run ./Terminal_Escape.exe to start"
echo "======================="
