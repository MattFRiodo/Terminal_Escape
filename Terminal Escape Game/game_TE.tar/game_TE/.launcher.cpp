#include <iostream>
#include <fstream>
using namespace std;

int main() {

    ifstream save(".Mission_Progress.txt");

    int unlocked = 1;
    int levels;
    if(save.is_open()) {
	while (save >> levels) {
	   unlocked = levels + 1;
	}
     }
	cout << "=====================================================================\n";
	cout << "			TERMINAL ESCAPE			\n";
	cout << "=====================================================================\n";

    cout << "Unlocked Levels:\n";

    for(int i = 1; i <= unlocked && i <= 6; i++) {
	if (i != 6) {
        cout << "[" << i << "] Level " << i << endl;
    }
}

	if(unlocked > 5)
	{
		cout << "\n Congratulations agent, You have completed the mission. Good work, soldier.\n";
		cout << "\n GAME FINISHED \n";
	}
int level;
    cout << "\n Select a Level:\n" << ">";
    cin >> level;
  if(level <= unlocked) {
	if(level == 1) {
	system("cd .Level_1 && bash");
	}

	else if(level == 2) {
	system("cd .Level_2 && bash");
	}

	else if(level == 3) {
	system("cd .Level_3 && bash");
	}

	else if(level == 4) {
	system("cd .Level_4 && bash");
	}

	else if(level == 5) {
	system("cd .Level_5 && bash");
 }
}
  else {
  cout << "Not Available\n";
  }

    return 0;
}
